document.getElementById("logoutBtn").addEventListener("click", function() {
    
    alert("Vous êtes déconnecté !");
    
    window.location.href = "main.html"; 
  });
  