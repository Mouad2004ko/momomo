#include<stdio.h>
#include<stdlib.h>

typedef struct Patient
{
 char Nom [20] ;
 char Prenom [20] ;
 int rdv ;

} Patient;









int main () {

do
{
    printf("Le patient a un rendez-vous ? :");
} 
while (rdv != 0 || rdv != 1);





}


