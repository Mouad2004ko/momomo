document.getElementById("signupForm").addEventListener("submit", function(event) {
    event.preventDefault(); 
    
   
    var username = document.getElementById("username").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    var Confirm_password = document.getElementById("Confirm_password").value;
   
    
    
    console.log("Username: " + username);
    console.log("Email: " + email);
    console.log("Password: " + password);
    console.log("Password: " + Confirm_password);
    
    if (Confirm_password == password ) {
      alert('Signup successful!');
      window.location.href = "main2.html";
  } else {
      alert('Confirmation Invalid . Please try again.');
  }
    
      

     
  });
  