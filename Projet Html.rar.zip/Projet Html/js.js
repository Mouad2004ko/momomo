document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault(); 

    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
   
    if (username === "Mouad" && password === "123" || username === "Younes" && password === "321") {
        alert('Login successful!');
        window.location.href = "main2.html";
    } else {
        alert('Invalid username or password. Please try again.');
    }
});
